# BOX-IT — Plataforma nacional de resiliencia financiera

Publicación: cargar el ZIP completo (index.html en la raíz) en https://vercel.com/drop. Proyecto estático, sin compilación, sin npm, sin API ni claves. El HTML incorpora CSS, JavaScript, gráficos y datos. La tipografía es nativa del sistema, sin dependencias de red.

## Alcance
- 2.000 negocios sintéticos, 25 ámbitos departamentales, 195 códigos provinciales y 1.827 distritos con geometría disponible (cartografía histórica nacional más 84 distritos de La Libertad). No es un inventario actualizado de todos los distritos legalmente existentes.
- Selección de perfiles de consulta, no autenticación real. Estados, asignaciones y notas se mantienen en memoria durante la sesión. No se envían datos a una institución financiera.
- Las amenazas, alertas y coeficientes de estrés del directorio son supuestos ilustrativos. No hay conexión en vivo a fuentes oficiales ni inferencia neuronal validada. Los indicadores originales de los experimentos financiero y predictivo se mantienen separados de la cartera operativa.
- Las capas documentales de La Libertad conservan las geometrías y resultados originales de BOX-IT. Los límites no son aptos para demarcación legal.

## Cartografía nacional
Derivada de juaneladio/peru-geojson, archivos departamental, provincial y distrital simplificados; fuente declarada INEI 2007, MINAM/GeoIDEP. Licencia del repositorio: Mozilla Public License 2.0 (LICENSE-cartografia.txt). Los datos transformados a trazados vectoriales están incluidos como JSON legible dentro de index.html (id geo-data). Se han redondeado coordenadas, proyectado y unido códigos provinciales duplicados. Referencias originales: https://github.com/juaneladio/peru-geojson ; blob departamental ba12177941ccc998eca08d197f2ad9c11cd8d55f, provincial 8b708a3f69368f6aa7e84ff02b9b6cfc24b9bdc8, distrital 178c0f36f6e803a1fc55aed48253dedf96390f04. La Libertad utiliza la capa de referencia 2024 ya disponible en BOX-IT, con sus capas de contexto documental independientes.

## Validación
132/132 comprobaciones de interfaz y flujo en Chromium a 1440, 1280 y 390 px; 8/8 comprobaciones complementarias. Se comprobó el arranque con CSP mediante meta local. La prueba HTTP externa fue bloqueada por el entorno; despliegue en Vercel y revisión de permisos FigJam pendientes. Sin solicitudes externas de red durante las pruebas de interfaz. No se afirma validación institucional ni producción.
